package com.example.myapplication;


import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;



public class Sign_up extends AppCompatActivity {

    private EditText et_fullName, et_password, et_email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);


        et_fullName = (EditText) findViewById(R.id.FullName);
        et_email = (EditText) findViewById(R.id.email);
        et_password = (EditText) findViewById(R.id.Password);
    }

    public void registerDB(View view) {
        String name = et_fullName.getText().toString();
        String email = et_email.getText().toString().trim();
        String password = et_password.getText().toString().trim();

        if (name.isEmpty()) {
            et_fullName.setError("Full Name is required");
            et_fullName.requestFocus();
            return;
        }
        if (email.isEmpty()) {
            et_email.setError("Email is required");
            et_email.requestFocus();
            return;
        }
        if (password.isEmpty() || password.length() < 6) { //you can also check the num. of chars.
            et_password.setError("Password is required and must be > 6");
            et_password.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            et_email.setError("Please provide valid Email");
            et_email.requestFocus();
            return;
        }

}}