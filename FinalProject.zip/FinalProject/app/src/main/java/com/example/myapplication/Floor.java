package com.example.myapplication;
import java.util.List;
import java.util.List;
import java.util.List;

public class Floor {
    private int number;
    private List<Section> sections;

    public Floor(int number, List<Section> sections) {
        this.number = number;
        this.sections = sections;
    }

    // Getters and setters
    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public List<Section> getSections() {
        return sections;
    }

    public void setSections(List<Section> sections) {
        this.sections = sections;
    }
}
